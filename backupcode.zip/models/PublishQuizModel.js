const mongoose = require('mongoose')
const { Schema } = mongoose
const PublishQuizSchema = new Schema(
  {
    quizname: {
      type: String,
      required: true,
    },
    quizcourse: {
      type: String,
      required: true,
    },
    quiztime: {
      type: String,
      required: true,
    },
    QAResults: [
      { type: mongoose.Schema.Types.ObjectId, ref: 'QuestionsAnswers' },
    ],
  },
  { timestamps: true }
)

module.exports = mongoose.model('PublishQuiz', PublishQuizSchema)
