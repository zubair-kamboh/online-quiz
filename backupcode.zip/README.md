Bright Boost Project

To install this project just download the zip folder, open the folder in vs code. firstly you have to install all the frontend/backend packages. you can do it by going into folder "brightboost-master" than click "npm install", after this step finishes than go to client folder and hit "npm install". After the installation you can run this project by going into client folder and than hit "npm run dev". Make sure you install nodejs and mongodbcompass. For testing the api use postman

![image](https://github.com/zubair-kamboh/bright-boost/assets/70833594/7e12ff7c-0cf9-4790-afeb-9d9bf0436cd0)
