const router = require('express').Router()

const {
  publishQuiz,
  publishQAResults,
} = require('../controllers/adminController')

router.post('/publishquiz', publishQuiz)
router.post('/publishQAResults', publishQAResults)

module.exports = router
