const router = require('express').Router()

const asynHandler = require('express-async-handler')
const asyncHandler = require('express-async-handler')
const StudentAuthModel = require('../models/StudentAuthModel')

const AdminSchema = require('../models/AdminAuthModel')

// Student SIGNUP
const studentSignUp = asynHandler(async (req, res) => {
  const {
    fullname,
    address,
    contact,
    email,
    password,
    username,
    state,
    postcode,
  } = req.body

  if (
    (!fullname || !address || !email || !password,
    !contact,
    !username,
    !state,
    !postcode)
  ) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const emailExist = await StudentAuthModel.findOne({ email })

  // check if email already exists
  if (emailExist) {
    res.status(400)
    throw new Error('Email already exists')
  }

  const doc = new StudentAuthModel({
    fullname,
    address,
    email,
    password,
    contact,
    username,
    state,
    postcode,
  })

  await doc.save()
  res.status(200).json({ successMsg: 'Student saved in db!' })
})

router.post('/student/signup', studentSignUp)

module.exports = router

module.exports = {
  studentSignUp,
}
