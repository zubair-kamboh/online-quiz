const asynHandler = require('express-async-handler')
const asyncHandler = require('express-async-handler')
const StudentAuthModel = require('../models/StudentAuthModel')

const AdminSchema = require('../models/AdminAuthModel')

// Student SIGNUP
const studentSignUp = asynHandler(async (req, res) => {
  const {
    fullname,
    address,
    contact,
    email,
    password,
    username,
    state,
    postcode,
  } = req.body

  if (
    (!fullname || !address || !email || !password,
    !contact,
    !username,
    !state,
    !postcode)
  ) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const emailExist = await StudentAuthModel.findOne({ email })

  // check if email already exists
  if (emailExist) {
    res.status(400)
    throw new Error('Email already exists')
  }

  const doc = new StudentAuthModel({
    fullname,
    address,
    email,
    password,
    contact,
    username,
    state,
    postcode,
  })

  await doc.save()
  res.status(200).json({ successMsg: 'Student saved in db!' })
})

// StudentSignIn
const studentSignIn = asynHandler(async (req, res) => {
  const { email, password } = req.body

  if (!email || !password) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const student = await StudentAuthModel.findOne({ email })

  // check if email do not exists
  if (!student) {
    res.status(400)
    throw new Error("Email does'nt exist! Please sign up first")
  }

  // if passwords do not match
  if (student.password !== password) {
    res.status(400)
    throw new Error('Incorrect password!')
  }

  // sign in student
  res.json({
    successMsg: 'Sign in successfully!',
    student: {
      _id: student._id,
      fullname: student.fullname,
      address: student.address,
      contact: student.contact,
      email: student.email,
      username: student.username,
      state: student.state,
      postcode: student.postcode,
    },
  })
})

// ADMIN SIGNUP
const adminSignUp = asyncHandler(async (req, res) => {
  const { email, password } = req.body

  if (!email || !password) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const emailExist = await AdminSchema.findOne({ email })

  // check if email already exists
  if (emailExist) {
    res.status(400)
    throw new Error('Email already exists')
  }

  const doc = new AdminSchema({
    email,
    password,
  })

  await doc.save()
  res.status(200).json({ successMsg: 'Admin saved in db!' })
})

// Admin Sign In
const adminSignIn = asynHandler(async (req, res) => {
  const { email, password } = req.body

  if (!email || !password) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const admin = await AdminSchema.findOne({ email })

  // check if email do not exists
  if (!admin) {
    res.status(404)
    throw new Error("Email does'nt exist! Please sign up first")
  }

  // if passwords do not match
  if (admin.password !== password) {
    res.status(400)
    throw new Error('Incorrect password!')
  }

  // sign in admin
  res.json({
    successMsg: 'Sign in successfully!',
    admin: {
      _id: admin._id,
      fullname: admin.fullname,
      address: admin.address,
      email: admin.email,
    },
  })
})

module.exports = {
  studentSignUp,
  studentSignIn,
  adminSignUp,
  adminSignIn,
}
