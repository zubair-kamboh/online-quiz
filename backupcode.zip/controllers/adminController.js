const asyncHandler = require('express-async-handler')
const PublishQuizModel = require('../models/PublishQuizModel')
const QuestionsAnswersModel = require('../models/QuestionsAnswersModel')

// Admin Publish Quiz
// METHOD POST
// ENDPOINT /admin/publishquiz
const publishQuiz = asyncHandler(async (req, res) => {
  const { quizname, quizcourse, quiztime } = req.body

  if (!quizname || !quizcourse || !quiztime) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const doc = new PublishQuizModel({
    quizname,
    quizcourse,
    quiztime,
  })

  const quizSaved = await doc.save()

  if (!quizSaved) {
    res.status(400)
    throw new Error('Something went wrong')
  }

  res
    .status(200)
    .json({ successMsg: 'Quiz has been published!', quiz: quizSaved })
})

// Admin Questions Answers & Results
// METHOD POST
// ENDPOINT /admin/publishQAResults
const publishQAResults = asyncHandler(async (req, res) => {
  const { q1, q2, q3, q4, q5, a1, a2, a3, a4, a5, result, quizId } = req.body

  if (
    !q1 ||
    !q2 ||
    !q3 ||
    !q4 ||
    !q5 ||
    !a1 ||
    !a2 ||
    !a3 ||
    !a4 ||
    !a5 ||
    !result ||
    !quizId
  ) {
    res.status(400)
    throw new Error('Please include all fields')
  }

  const foundQuizId = await PublishQuizModel.findById(quizId)

  if (!foundQuizId) {
    res.status(404)
    throw new Error('Quiz not found! Data cannot be saved!')
  }

  const doc = new QuestionsAnswersModel({
    q1,
    q2,
    q3,
    q4,
    q5,
    a1,
    a2,
    a3,
    a4,
    a5,
    result,
    quizId,
  })

  const dataSaved = await doc.save()

  if (!dataSaved) {
    res.status(400)
    throw new Error('Something went wrong')
  }

  if (dataSaved) {
    const doc = await PublishQuizModel.findOne({ _id: quizId })
    doc.QAResults.push(dataSaved._id)
    doc.save()
  }

  const newDataOfPublishQuiz = foundQuizId.QAResults.push(dataSaved._id)

  console.log(dataSaved._id)

  res
    .status(200)
    .json({ successMsg: 'Quiz Data saved in db!', data: dataSaved })
})

module.exports = {
  publishQuiz,
  publishQAResults,
}
